# joshua-okine-ilgspe190065
 Activity 2
